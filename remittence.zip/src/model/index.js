const userModel = require("./user.model");
const permisionModel = require("./permission.model.js");
const operationModel = require("./operation.model.js");
const customerModel = require("./customer.model");
const remittenceModel = require("./remittence.model.js");

module.exports = { userModel, permisionModel, operationModel, customerModel,remittenceModel };
