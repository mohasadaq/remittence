const userValidation = require("./user.validation");
const authValidation = require("./auth.validation");
const customerValidation = require("./customer.validation");
const remittenceValidation = require("./remittence.validation");

module.exports = { userValidation, authValidation, customerValidation,remittenceValidation };
